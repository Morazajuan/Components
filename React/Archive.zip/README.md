# Card Slider Component in React

### For this component you will have to run
### npm install
### npm install browserify-fs 
### npm install redux
### npm install react-redux

## Firebase
### npm install grpc --verbose
### npm install firebase


![](demo.gif)
